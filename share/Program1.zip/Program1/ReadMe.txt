This program provides a simple, text-based simulation of a basic banking system. 
It should demonstrates key concepts such as classes, objects, user input handling, 
control flow, and error handling in a Java program.
