REST APIS for todo application(Spring Boot), to add update and delete todos.
Please note there is no repository, save update is done using Arrays.